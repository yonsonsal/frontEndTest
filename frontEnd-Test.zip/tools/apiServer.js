const express = require("express");
const cors = require("cors");
const fetch = require("node-fetch");
const { from } = require("rxjs");
const { map, flatMap, mergeMap, toArray } = require("rxjs/operators");

const app = express();
app.use(cors());

var port = process.env.PORT || 3001;

const itemsRouter = express.Router();

/**
 *
 * @param { filters array from JSON query} filters
 * returns String array with name of the category of the filter
 */

const flatCategories = filters => {
  const pluckedCategoryArray = filters
    .filter(_filter => _filter.id == "category")[0]
    .values[0].path_from_root.map(path => path.name);
  return pluckedCategoryArray;
};

itemsRouter.get("/items", (req, res) => {
  const { query } = req;
  console.log(query.q);
  const queryStr = "q=" + query.q;
  const url = "https://api.mercadolibre.com/sites/MLA/search?" + queryStr;
  const urlItem = "https://api.mercadolibre.com/items/;

  console.log(queryStr);

  const pictureStr =
    "https://mla-s1-p.mlstatic.com/823167-MLA31021182751_062019-O.jpg";

  const request$ = from(fetch(url)).pipe(flatMap(response => response.json()));

  //request$.pipe(map(x => x.results)).subscribe(result => res.json(result));
  const fetchResults$ = request$.pipe(
    map(x => {
      x.results;
    })
  );

  const fetchResults2$ = request$.pipe(map(x => buildResponse(x)));

  const addPicture = item => {
    return { ...item, picture: pictureStr };
  };

  const buildResponse = searchResponse => {
    return {
      categories: flatCategories(searchResponse.filters),
      items: searchResponse.results
    };
  };

  console.log(addPicture({}));

  //fetch$.subscribe(x => console.log(x.length));

  //(fetch$).pipe(map(arr=>from(array)).subscribe(x => console.log("x-->",x));

  //const fetch$ = from(fetch(url)).pipe(flatMap(response => response.json()));

  /*
  fetchResults$
    .pipe(
      map(x => from(x)),
      mergeMap(item => item),
      map(item => addPicture(item)),
      toArray()
    )
    .subscribe(x => res.json(x));


*/

  // .subscribe(result => res.json({ ...result, picture: pictureStr }));

  fetchResults2$.subscribe(x => res.json(x));
});
app.use("/api", itemsRouter);
app.get("/", (req, res) => {
  res.send("Welcome to my API");
});

app.listen(port, () => {
  console.log("Listening  server in port" + port);
});


const processItem=(itemObservableArray)=>{
  return itemObservableArray.pipe(
    mergeMap(item => from(fetch(`${urlItem}/${item.id}`)))
    .map(_item=>{
    return _item;
    })
  );}

  const mapItemPrice=(item)=>{
    const{price,currency_id}=item;
    const{amount,decimals} = buildCurrencyfromPrice(price);

    let _price = {
      currency: currency_id,
      amount: amount,
      decimals: decimals,
      }
      return{...item,{price:_price}};
  };
const mapItemImage=(item)=>{
    return item.pictures[0].url;
  }


  {
    "id": String,
    "title": String,
    ,
    “picture”: String,
    "condition": String,
    "free_shipping": Boolean
    }


    const pluckItem=(item)=>{
      
     const price={
        currency: "ARS",
        amount: 999,
        decimals: 99
        }
      const{id,title,condition}=item;
      const {shipping:free_shipping} = item;

    }



    function buildCurrencyfromPrice(price) {
      
      const  _amount = price/1000;
      const _decimals = price %1000;
      const  _amount = price/1000;
      const amounts = _amount ==0?_decimal :_amount;
      const decimals = _decimal ==price ?0 :_decimal;

      return {amount:amount,decimals:decimals}
     // return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    }